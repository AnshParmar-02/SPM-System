-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2024 at 02:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `product`
--

-- --------------------------------------------------------

--
-- Table structure for table `fertilizer`
--

CREATE TABLE `fertilizer` (
  `f_id` int(11) NOT NULL,
  `fertilizer_name` varchar(50) NOT NULL,
  `f_price` varchar(50) NOT NULL,
  `f_description` varchar(50) NOT NULL,
  `f_image` varchar(2000) NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fertilizer`
--

INSERT INTO `fertilizer` (`f_id`, `fertilizer_name`, `f_price`, `f_description`, `f_image`, `trn_date`) VALUES
(1, 'Borofert 11', '170', 'Borofert 11 - 11% Boron endowed with calcium, mg &', 'ferti6.jpg', '2024-04-19 21:01:11'),
(2, 'Zotal - Bo Liquid', '400', 'Zotal-Bo is a formulation of glycine-chelated boro', 'ferti5.jpg', '2024-04-19 21:04:34'),
(3, 'Pushti Vardan elixer', '250', 'This is agriculture speciality fertilizer', 'ferti3.jpg', '2024-04-19 21:06:23'),
(4, 'Magnesium Sulphate - 5kg', '300', 'Magnesium sulphate contains 9.5% mg and 12% sulphe', 'fer1.jpg', '2024-04-19 21:07:26'),
(5, 'Zotal - Ca liquid-500ml', '385', 'Zinc glycinate are glycine mineral used for foiler', 'fer2.jpg', '2024-04-19 21:08:24');

-- --------------------------------------------------------

--
-- Table structure for table `home_product`
--

CREATE TABLE `home_product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `product_image` varchar(2000) NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `home_product`
--

INSERT INTO `home_product` (`id`, `product_name`, `price`, `description`, `product_image`, `trn_date`) VALUES
(1, 'Munsyari Rajma (1kg)', '400', 'GI tagged rajma, cultivation in high altitude', '11.jpg', '2024-04-18 19:33:54'),
(2, 'Niimpa 3000', '600', 'Niimpa is a Azadirachtin based pesticide.', '22.jpg', '2024-04-18 19:42:50'),
(3, 'Bhindi seed', '250', 'seed color : dark green, rate: 10-12 kg/acre', 'seed3.jpg', '2024-04-19 11:22:12'),
(4, 'Sil-One (liquid)', '200', 'This non-ionic agent is a super spreader with good', 'pesticide1.jpg', '2024-04-19 11:33:16'),
(5, 'Shimo - 60ml', '700', 'This is a broad spectrum insecticide.', 'product2.jpg', '2024-04-19 11:36:17'),
(6, 'Ryegrass TS - 500g', '275', 'Rye grass is a winter forage crop.', 'seed1.jpg', '2024-04-19 15:39:31'),
(7, 'Vegetable seed kit', '150', 'Beetroot, Turnip, Coriander, Spinach, Okra, Bean', 'seed2.jpg', '2024-04-19 15:41:58'),
(8, 'Zotal - Ca liquid-500ml', '385', 'Zinc glycinate are glycine mineral used for foiler', 'fer2.jpg', '2024-04-19 15:57:38'),
(9, 'Magnesium Sulphate - 5kg', '300', 'Magnesium sulphate contains 9.5% mg and 12% sulphe', 'fer1.jpg', '2024-04-19 15:59:56');

-- --------------------------------------------------------

--
-- Table structure for table `pesticide`
--

CREATE TABLE `pesticide` (
  `p_id` int(11) NOT NULL,
  `pesticide_name` varchar(50) NOT NULL,
  `p_price` varchar(50) NOT NULL,
  `p_description` varchar(50) NOT NULL,
  `p_image` varchar(2000) NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pesticide`
--

INSERT INTO `pesticide` (`p_id`, `pesticide_name`, `p_price`, `p_description`, `p_image`, `trn_date`) VALUES
(1, 'Zakiyama', '600', 'Zakiyama belongs to dinitroaniline chemical group', 'pesticide2.jpg', '2024-04-19 20:32:48'),
(2, 'Furusato(500ml)', '800', 'Furusato is recommended on onion', 'pesticide3.jpg', '2024-04-19 20:35:00'),
(3, 'Sil-One (liquid)', '200', 'This non-ionic agent is a super spreader with good', 'pesticide1.jpg', '2024-04-19 20:36:12'),
(4, 'Kabuto', '450', 'Kabuto is control a wide range of annual grasses.', 'pesticide4.jpg', '2024-04-19 20:37:36'),
(6, 'Yutori', '800', 'Yutori is a broad spectrum post-emergence herbicid', 'pesticide5.jpg', '2024-04-20 06:15:44');

-- --------------------------------------------------------

--
-- Table structure for table `seed`
--

CREATE TABLE `seed` (
  `s_id` int(11) NOT NULL,
  `seed_name` varchar(50) NOT NULL,
  `s_price` varchar(50) NOT NULL,
  `s_description` varchar(50) NOT NULL,
  `s_image` varchar(2000) NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seed`
--

INSERT INTO `seed` (`s_id`, `seed_name`, `s_price`, `s_description`, `s_image`, `trn_date`) VALUES
(1, 'Bhindi seed', '250', 'seed color : dark green, rate: 10-12 kg/acre', 'seed3.jpg', '2024-04-19 19:02:33'),
(2, 'Vegetable seed kit', '150', 'Beetroot, Turnip, Coriander, Spinach, Okra, Bean', 'seed2.jpg', '2024-04-19 19:04:21'),
(3, 'Ryegrass TS - 500g', '275', 'Rye grass is a winter forage crop.', 'seed1.jpg', '2024-04-19 19:06:49'),
(4, 'Capsicum seed', '720', 'This seed is very strong disease resistance', 'seed5.jpg', '2024-04-19 19:16:18'),
(5, 'Kitchen Garden Vegetable seed', '160', '9 varieties seeds', 'seed6.jpg', '2024-04-19 19:19:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fertilizer`
--
ALTER TABLE `fertilizer`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `home_product`
--
ALTER TABLE `home_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pesticide`
--
ALTER TABLE `pesticide`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `seed`
--
ALTER TABLE `seed`
  ADD PRIMARY KEY (`s_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fertilizer`
--
ALTER TABLE `fertilizer`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `home_product`
--
ALTER TABLE `home_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pesticide`
--
ALTER TABLE `pesticide`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `seed`
--
ALTER TABLE `seed`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
