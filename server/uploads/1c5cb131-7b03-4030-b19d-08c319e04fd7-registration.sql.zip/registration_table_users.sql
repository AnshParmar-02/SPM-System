
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `username`, `password`, `trn_date`) VALUES
(1, 'Rishiraj', 'dabhi', 'rishi12', '827ccb0eea8a706c4c34a16891f84e7b', '2024-04-20 07:13:50'),
(2, 'Ansh', 'Parmar', 'ansh12', 'b0baee9d279d34fa1dfd71aadb908c3f', '2024-04-21 21:40:10');
